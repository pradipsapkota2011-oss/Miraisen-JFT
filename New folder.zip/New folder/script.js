let userAnswers = [];
let currentQuestion = 0;
let totalSeconds = 60 * 60;
let submitted = false;

function getSectionName(){
  if(currentQuestion < 12) return "Script and Vocabulary";
  if(currentQuestion < 24) return "Conversation and Expression";
  if(currentQuestion < 36) return "Listening";
  return "Reading";
}

function getSectionStart(){
  if(currentQuestion < 12) return 0;
  if(currentQuestion < 24) return 12;
  if(currentQuestion < 36) return 24;
  return 36;
}

function updateSectionHighlight(){
  document.querySelectorAll(".sec").forEach(sec => sec.classList.remove("activeSec"));

  if(currentQuestion < 12) document.getElementById("sec1").classList.add("activeSec");
  else if(currentQuestion < 24) document.getElementById("sec2").classList.add("activeSec");
  else if(currentQuestion < 36) document.getElementById("sec3").classList.add("activeSec");
  else document.getElementById("sec4").classList.add("activeSec");
}

function loadQuestion(){
  const q = questions[currentQuestion];

  document.getElementById("questionInfo").innerHTML =
    `<b>Question: ${currentQuestion + 1}</b><br><b>Section: ${getSectionName()}</b>`;

  let html = "";

  if(q.instruction){
    html += `<div class="instruction">${q.instruction}</div>`;
  }

  if(q.subtitle){
    html += `<div class="subtitle">${q.subtitle}</div>`;
  }

  if(q.question && q.type !== "dialog"){
    html += `<div class="mainQuestion">${q.question}</div>`;
  }

  document.getElementById("questionText").innerHTML = html;

  const imgBox = document.querySelector(".image");
  const img = document.getElementById("questionImage");

  if(q.image && q.type !== "dialog"){
    img.src = q.image;
    imgBox.style.display = "block";
  }else{
    img.src = "";
    imgBox.style.display = "none";
  }

  const audioBox = document.getElementById("audioBox");
  const audioPlayer = document.getElementById("audioPlayer");
  const audioSource = document.getElementById("audioSource");

  if(q.audio){
    audioPlayer.pause();
    audioPlayer.currentTime = 0;
    audioSource.src = q.audio;
    audioPlayer.load();
    audioBox.style.display = "block";
  }else{
    audioPlayer.pause();
    audioSource.src = "";
    audioPlayer.load();
    audioBox.style.display = "none";
  }

  const speakerBox = document.getElementById("speakerBox");
  const speakerImg = document.getElementById("speakerImg");

  if(q.speakerImage){
    speakerImg.src = q.speakerImage;
    speakerBox.style.display = "block";
  }else{
    speakerImg.src = "";
    speakerBox.style.display = "none";
  }

  if(q.type === "dialog"){
    loadDialogQuestion(q);
  }else if(q.type === "double"){
    loadDoubleQuestion(q);
  }else{
    loadSingleQuestion(q);
  }

  updateSectionHighlight();
  makePalette();
}

function loadSingleQuestion(q){
  const container = document.getElementById("optionContainer");
  container.innerHTML = "";

  const hasImageOptions = q.options.some(item => typeof item === "object" && item.image);

  if(hasImageOptions){
    container.className = "imageOptions";
  }else{
    container.className = "";
  }

  q.options.forEach((item, index) => {
    const option = document.createElement("div");
    option.className = hasImageOptions ? "option imageOption" : "option";

    if(typeof item === "string"){
      option.innerText = item;
    }else{
      if(item.image){
        option.innerHTML += `<img src="${item.image}" alt="">`;
      }

      if(item.text){
        option.innerHTML += `<div style="text-align:center;">${item.text}</div>`;
      }
    }

    if(userAnswers[currentQuestion] === index){
      option.classList.add("selected");
    }

    option.onclick = function(){
      selectSingleAnswer(index);
    };

    container.appendChild(option);
  });
}

function loadDialogQuestion(q){
  const container = document.getElementById("optionContainer");
  container.innerHTML = "";
  container.className = "";

  const dialogWrap = document.createElement("div");
  dialogWrap.className = "dialogWrap";

  const dialogText = document.createElement("div");
  dialogText.className = "dialogText";
  dialogText.innerHTML = q.dialog || "";

  dialogWrap.appendChild(dialogText);

  if(q.sideImage){
    const sideImg = document.createElement("img");
    sideImg.className = "dialogImage";
    sideImg.src = q.sideImage;
    sideImg.alt = "";
    dialogWrap.appendChild(sideImg);
  }

  container.appendChild(dialogWrap);

  q.options.forEach((item, index) => {
    const option = document.createElement("div");
    option.className = "option";

    if(typeof item === "string"){
      option.innerText = item;
    }else{
      if(item.image){
        option.innerHTML += `<img src="${item.image}" alt="">`;
      }

      if(item.text){
        option.innerHTML += `<div style="text-align:center;">${item.text}</div>`;
      }
    }

    if(userAnswers[currentQuestion] === index){
      option.classList.add("selected");
    }

    option.onclick = function(){
      selectSingleAnswer(index);
    };

    container.appendChild(option);
  });
}

function loadDoubleQuestion(q){
  const container = document.getElementById("optionContainer");
  container.innerHTML = "";
  container.className = "";

  if(!userAnswers[currentQuestion]){
    userAnswers[currentQuestion] = {};
  }

  q.parts.forEach((part, partIndex) => {
    const partBox = document.createElement("div");
    partBox.className = "partBox";

    const title = document.createElement("div");
    title.className = "partTitle";
    title.innerText = part.title || part.question || "";

    partBox.appendChild(title);

    const row = document.createElement("div");
    row.className = "doubleOptionRow";

    part.options.forEach((item, optionIndex) => {
      const option = document.createElement("div");
      option.className = "option doubleOption";

      if(typeof item === "string"){
        option.innerText = item;
      }else{
        if(item.image){
          option.innerHTML += `<img src="${item.image}" alt="">`;
        }

        if(item.text){
          option.innerHTML += `<div style="text-align:center;">${item.text}</div>`;
        }
      }

      if(userAnswers[currentQuestion][partIndex] === optionIndex){
        option.classList.add("selected");
      }

      option.onclick = function(){
        selectDoubleAnswer(partIndex, optionIndex);
      };

      row.appendChild(option);
    });

    partBox.appendChild(row);
    container.appendChild(partBox);
  });
}

function selectSingleAnswer(index){
  userAnswers[currentQuestion] = index;
  loadQuestion();
}

function selectDoubleAnswer(partIndex, optionIndex){
  if(!userAnswers[currentQuestion]){
    userAnswers[currentQuestion] = {};
  }

  userAnswers[currentQuestion][partIndex] = optionIndex;
  loadQuestion();
}

function makePalette(){
  const palette = document.getElementById("palette");
  palette.innerHTML = "";

  let start = getSectionStart();
  let end = Math.min(start + 12, questions.length);

  for(let i = start; i < end; i++){
    const btn = document.createElement("div");
    btn.className = "qbtn";
    btn.innerText = i + 1;

    if(i === currentQuestion) btn.classList.add("active");

    btn.onclick = function(){
      currentQuestion = i;
      loadQuestion();
    };

    palette.appendChild(btn);
  }
}

function submitTest(){
  if(submitted) return;
  submitted = true;

  let correct = 0;
  let wrong = 0;
  let unanswered = 0;
  let totalMarks = 0;

  for(let i = 0; i < questions.length; i++){
    const q = questions[i];

    if(q.type === "double"){
      q.parts.forEach((part, partIndex) => {
        totalMarks++;

        if(!userAnswers[i] || userAnswers[i][partIndex] === undefined){
          unanswered++;
        }else if(userAnswers[i][partIndex] === part.answer){
          correct++;
        }else{
          wrong++;
        }
      });
    }else{
      totalMarks++;

      if(userAnswers[i] === undefined){
        unanswered++;
      }else if(userAnswers[i] === q.answer){
        correct++;
      }else{
        wrong++;
      }
    }
  }

  let percent = Math.round((correct / totalMarks) * 100);

  document.getElementById("scoreText").innerHTML = `<b>Total Score:</b> ${correct} / ${totalMarks}`;
  document.getElementById("correctText").innerHTML = `<b>Correct:</b> ${correct}`;
  document.getElementById("wrongText").innerHTML = `<b>Wrong:</b> ${wrong}`;
  document.getElementById("unansweredText").innerHTML = `<b>Unanswered:</b> ${unanswered}`;
  document.getElementById("percentText").innerHTML = `<b>Percentage:</b> ${percent}%`;

  document.getElementById("resultBox").style.display = "block";
}

function closeResult(){
  document.getElementById("resultBox").style.display = "none";
}

function openLanguage1(){
  document.getElementById("langModal1").style.display = "block";
}

function closeLanguage1(){
  document.getElementById("langModal1").style.display = "none";
}

document.getElementById("nextBtn").onclick = function(){
  if(currentQuestion < questions.length - 1){
    currentQuestion++;
    loadQuestion();
  }else{
    submitTest();
  }
};

document.getElementById("backBtn").onclick = function(){
  if(currentQuestion > 0){
    currentQuestion--;
    loadQuestion();
  }
};

document.querySelector(".finish").onclick = function(){
  submitTest();
};

function updateTimer(){
  let minutes = Math.floor(totalSeconds / 60);
  let seconds = totalSeconds % 60;

  document.getElementById("time").innerText =
    String(minutes).padStart(2,"0") + ":" +
    String(seconds).padStart(2,"0");

  if(totalSeconds > 0){
    totalSeconds--;
  }else{
    submitTest();
  }
}

loadQuestion();
updateTimer();
setInterval(updateTimer, 1000);